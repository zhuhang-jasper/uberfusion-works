package fourtified_test_2;

import java.math.BigInteger;
import shared.Keyboard;

public class Client extends Keyboard{

	public static void main(String[] args) {
		
		boolean exit = false;
		do{
			System.out.println("------TASK 2 (Check Digit)------");
			System.out.println("1. Basic");
			System.out.println("2. Advance (NOT ANSWERED)");
			int option = getInt("Choose Option: (0 to exit)",true);
			switch(option){
				case 1: {
					// Task 2 (Basic):
					System.out.println("Input values:");
					BigInteger value =  getBigInt("1. Value to generate reference number (Eg. 543215432154321): ");
					int checkDigit = getCheckDigit(value);
					System.out.println("The check digit is \"" + checkDigit + "\"");
					System.out.println("The generated reference number is \"" + value.toString() + checkDigit + "\"");
					break;
				}
				case 0: exit = true; break;
				default: System.out.println("Invalid option!"); break;
			}
		} while(!exit);
		
	}
	
	public static int getCheckDigit(BigInteger value){
		
		char[] digits = value.toString().toCharArray();
		
		// Sum A,B,C
		int sum = 0;
		for(int i = 0 ; i < digits.length ; i++){
			int temp = Character.getNumericValue(digits[i]);
			switch(i%3){
				case 0: sum+=(temp*3); break;
				case 1: sum+=(temp*5); break;
				case 2: sum+=(temp*7); break;
				default: sum+=0; break;
			}
		}
		
		// Sum numeral digits until one digit
		int finalNum = sum; 
		while (Integer.toString(finalNum).length() > 1){
			sum = 0;
			while (finalNum > 0) {
	            sum += finalNum % 10;
	            finalNum /= 10;
	        }
			finalNum = sum;
		}
		
		return finalNum;
	}

}
