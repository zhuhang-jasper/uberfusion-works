package shared;

import java.math.BigInteger;
import java.util.Scanner;

public class Keyboard {
	public static Scanner input = new Scanner(System.in);
	
	public static double getDouble(String msg){
		// default disallow zero inputs
		return getDouble(msg,false);
	}
	
	public static double getDouble(String msg,boolean allowZero){
		System.out.println(msg);
		double num;
		do {
			while (!input.hasNextDouble()){
				System.out.println("Input invalid!");
				input.next();
			}
			num = input.nextDouble();
			input.nextLine();
			if((allowZero && num >= 0) || !allowZero && num > 0)
				break;
			else if (!allowZero && num == 0)
				System.out.println("Enter value greater than zero!");
			else
				System.out.println("Enter positive value!");
		} while(true);
		
		return num;
	}
	
	public static int getInt(String msg){
		// default disallow zero inputs
		return getInt(msg,false);
	}
	
	public static int getInt(String msg,boolean allowZero){
		System.out.println(msg);
		int num;
		do {
			while (!input.hasNextInt()){
				System.out.println("Input invalid!");
				input.next();
			}
			num = input.nextInt();
			input.nextLine();
			if((allowZero && num >= 0) || !allowZero && num > 0)
				break;
			else if (!allowZero && num == 0)
				System.out.println("Enter value greater than zero!");
			else
				System.out.println("Enter positive value!");
		} while(true);
		
		return num;
	}
	
	public static float getFloat(String msg){
		// default disallow zero inputs
		return getFloat(msg,false);
	}
	
	public static float getFloat(String msg,boolean allowZero){
		System.out.println(msg);
		float num;
		do {
			while (!input.hasNextFloat()){
				System.out.println("Input invalid!");
				input.next();
			}
			num = input.nextFloat();
			input.nextLine();
			if((allowZero && num >= 0) || !allowZero && num > 0)
				break;
			else if (!allowZero && num == 0)
				System.out.println("Enter value greater than zero!");
			else
				System.out.println("Enter positive value!");
		} while(true);
		
		return num;
	}
	
	public static BigInteger getBigInt(String msg){
		// default disallow zero inputs
		return getBigInt(msg,false);
	}
	
	public static BigInteger getBigInt(String msg,boolean allowZero){
		System.out.println(msg);
		BigInteger num;
		do {
			while (!input.hasNextFloat()){
				System.out.println("Input invalid!");
				input.next();
			}
			num = input.nextBigInteger();
			if((allowZero && num.compareTo(BigInteger.ZERO) >= 0) || !allowZero && num.compareTo(BigInteger.ZERO) > 0)
				break;
			else if (!allowZero && num.compareTo(BigInteger.ZERO) == 0)
				System.out.println("Enter value greater than zero!");
			else
				System.out.println("Enter positive value!");
		} while(true);
		
		return num;
	}
	
	public static String getString(String msg){
		System.out.println(msg);
		while (!input.hasNext()){
			System.out.println("Input invalid!");
			input.nextLine();
		}
		return input.nextLine();
	}
	
	
	
}
