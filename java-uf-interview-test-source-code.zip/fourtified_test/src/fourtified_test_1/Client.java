package fourtified_test_1;

import java.lang.Math;
import shared.Keyboard;

public class Client extends Keyboard{

	public static void main(String[] args) {
		
		boolean exit = false;
		do{
			System.out.println("------TASK 1 (Loan Calculations)------");
			System.out.println("1. Basic");
			System.out.println("2. Advance");
			int option = getInt("Choose Option: (0 to exit)",true);
			switch(option){
				case 1: {
					// Task 1 (Basic):
					System.out.println("Input values:");
					float property_val = getFloat("1. Value of property (regardless loan amount): ");
					float loan_amt_percent = getFloat("2. Loan amount (Eg. 90 = 90% of property value): ");
					float interest_annum = getFloat("3. Interest rate per annum (Eg. 4.65 = 4.65%): ");
					int period_year = getInt("4. Loan paypack period (Eg. 30 = 30years): ");
					float pymt_monthly = calcLoanPayment(property_val, loan_amt_percent, interest_annum, period_year);
					System.out.println("Monthly Repayment is: RM " + String.format("%.2f", pymt_monthly));
					break;
				}
				case 2: {
					// Task 1 (Advanced):
					System.out.println("Input values:");
					float property_val2 = getFloat("1. Value of property (regardless loan amount): ");
					float loan_amt_percent2 = getFloat("2. Loan amount (Eg. 90 = 90% of property value): ");
					float interest_annum2 = getFloat("3. Interest rate per annum (Eg. 4.65 = 4.65%): ");
					float pymt_monthly2 = getFloat("4. Monthly Payment ability (Eg. 2000 = RM 2000) : ");
					float period_year2 = calcLoanPeriod(property_val2, loan_amt_percent2, interest_annum2, pymt_monthly2);
					System.out.println("Duration to payback loan: " + String.format("%.1f", period_year2) + " years.");
					
					// Check loan approval
					if(period_year2 > 35){
						System.out.println("Loan rejected.");
						float loan_amt = calcLoanAmount(interest_annum2, 30, pymt_monthly2);
						System.out.println("Maximum loan allowed based on repay ability: ");
						System.out.println(String.format("RM %.2f for 30 years.", loan_amt));
					}
					else {
						System.out.println("Loan approved.");
					}
					break;
				}
				case 0: exit = true; break;
				default: System.out.println("Invalid option!"); break;
			}
		} while(!exit);
		
	}
	
	public static float calcLoanPayment(float property_val,float loan_amt_percent,float interest_annum, int period_year) {
		
		float loan_amt = property_val/100*(loan_amt_percent);
		float interest_month = interest_annum/100/12;
		int period_month = period_year*12;
		
		//formula for amortization schedule
		double repayment = loan_amt * (interest_month * Math.pow(1+interest_month,period_month) ) / (Math.pow(1+interest_month,period_month) - 1);
		
		//force round up to one sen
		return (float)Math.ceil(repayment*100)/100;
	}
	
	public static float calcLoanPeriod(float property_val,float loan_amt_percent,float interest_annum, float pymt_monthly) {
		
		float loan_amt = property_val/100*(loan_amt_percent);
		float interest_month = interest_annum/100/12;
		
		//formula for "n" derived from amortization schedule formula
		double period_month = Math.log10(pymt_monthly/(pymt_monthly-(loan_amt*interest_month))) / Math.log10(1+interest_month);
		
		//force round up to one month
		return (float)Math.ceil(period_month)/12;
	}
	
	public static float calcLoanAmount(float interest_annum, int period_year, float pymt_monthly) {
		
		float interest_month = interest_annum/100/12;
		int period_month = period_year*12;
		
		//formula for "P" derived from amortization schedule formula
		double loan_amt = pymt_monthly * (Math.pow(1+interest_month,period_month) - 1) / (interest_month * Math.pow(1+interest_month,period_month));
		
		return (float)Math.round(loan_amt * 100) / 100;
	}
	


}
