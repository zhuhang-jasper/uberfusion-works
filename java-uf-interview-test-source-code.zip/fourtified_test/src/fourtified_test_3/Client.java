package fourtified_test_3;

import java.util.ArrayList;
import shared.Keyboard;

public class Client extends Keyboard{

	public static void main(String[] args) {
		
		boolean exit = false;
		do{
			System.out.println("------TASK 3 (Cyclic & Reverse Cyclic Sort)------");
			System.out.println("1. Basic");
			System.out.println("2. Advance");
			int option = getInt("Choose Option: (0 to exit)",true);
			switch(option){
				case 1: {
					// Task 3 (Basic):
					System.out.println("Input values:");
					String text = getString("1. Text to perform cyclic sort (Eg. 0123456789ABCDEF): ");
					int order = getInt("2. Number of ordering to sort (Eg. 11): ");
					char[] input = text.toCharArray();
					char[] output = cyclicSort(input, order);
					System.out.println("Output: " + new String(output)); 
					break;
				}
				case 2: {
					// Task 3 (Advance):
					System.out.println("Input values:");
					String text2 = getString("1. Text to perform reverse cyclic sort (Eg. A51ECBD049783F26): ");
					int order2 = getInt("2. Number of ordering the text was sorted with (Eg. 11): ");
					char[] input2 = text2.toCharArray();
					char[] output2 = reverseCyclicSort(input2, order2);
					System.out.println("Original Message: \"" + new String(output2) + "\"");
					break;
				}
				case 0: exit = true; break;
				default: System.out.println("Invalid option!"); break;
			}
		} while(!exit);
		
	}
	
	public static char[] cyclicSort(char[] input, int ordering) {
		
        // Convert array to arraylist
		ArrayList<Character> outputList = new ArrayList<Character>();
		ArrayList<Character> inputList = new ArrayList<Character>();
		for(char c: input){
			inputList.add(c);
		}
		
		// Sorting in arraylist
		int cursor_loc = 0;
		while (inputList.size() > 0){
			cursor_loc += (ordering - 1);
			cursor_loc = cursor_loc%(inputList.size());
			outputList.add(inputList.get(cursor_loc));
			inputList.remove(cursor_loc);
		}
		
		// Convert arraylist back to array
		char[] output = new char[outputList.size()];
		for(int i = 0; i < output.length ; i++){
			output[i] = outputList.get(i);
		}
		
		return output;
    }
	
	public static char[] reverseCyclicSort(char[] input, int ordering) {
		
		// Declare array for final output
		char[] output = new char[input.length];
		
		// Create an dummy ArrayList of index values matching input size
		ArrayList<Integer> indexList = new ArrayList<Integer>();
		for(int i = 0; i < input.length ; i++){
			indexList.add(i);
		}
		
		// Perform cyclic sort on the indexList
		// The element removed contains the index position
		int cursor_loc = 0;
		for (int i = 0; indexList.size() > 0 ; i++){
			cursor_loc += (ordering - 1);
			cursor_loc = cursor_loc%(indexList.size());
			output[indexList.get(cursor_loc)] = input[i];
			indexList.remove(cursor_loc);
		}
		
		return output;
    }
}
