# Support Wheel of Fate

A RESTful web service to generate 'Support Wheel of Fate' schedule.

### Compile
Prerequisite: Use Gradle version 4.6 & Java 8.

Execute 1.build.bat (Windows) or:
```
gradle clean build
```

### Start Application
Execute 2.run.bat (Windows) or:
```
java -jar build/libs/astro-swof-rest-service-1.0.0.jar
```

### Web UI
##### Local (HTTP)
http://127.0.0.1:8080 or http://127.0.0.1:8080/swof
##### Microsoft Azure (HTTPS)
https://astro-support-wheel-of-fate.azurewebsites.net/swof

### Swagger API Docs
http://127.0.0.1:8080/v2/api-docs<br>
https://astro-support-wheel-of-fate.azurewebsites.net/v2/api-docs

### Swagger-UI
http://127.0.0.1:8080/swagger-ui.html#/<br>
https://astro-support-wheel-of-fate.azurewebsites.net/swagger-ui.html#/

### API URL
http://127.0.0.1:8080/swof-api<br>
https://astro-support-wheel-of-fate.azurewebsites.net/swof-api

```
{
  "responseCode": "AA",
  "errCode": "",
  "errDesc": "",
  "request": {
    "startDate": "",
    "noOfWeeks": "2",
    .....
  },
  "body": {
    "maxShiftsPerEmp": 2,
    "schedule": [
      {
        "weekNumber": 1,
        "dailySchedule": [
          {
            "dateStr": "Mon, 13-Aug-2018",
            "shift": [
              {
                "shiftNumber": 1,
                "dutyOfTheShift": [
                  {
                    "empId": 2,
                    "empName": "Employee"
                  }
                ]
              },
              .....
            ]
          },
          .....
        ]
      },
      .....
    ]
  }
}
```
