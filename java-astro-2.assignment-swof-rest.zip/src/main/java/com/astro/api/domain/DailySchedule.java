package com.astro.api.domain;

import java.util.List;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class DailySchedule {

    private String dateStr;
    private List<Shift> shift;

    public DailySchedule(String dateStr) {
        this.dateStr = dateStr;
    }

    public String getDateStr() {
        return dateStr;
    }

    public void setDate(String dateStr) {
        this.dateStr = dateStr;
    }

    public List<Shift> getShift() {
        return shift;
    }

    public void setShift(List<Shift> shift) {
        this.shift = shift;
    }

    @Override
    public String toString() {
        return String.format("Schedule for %s:\n%s", dateStr, Shift.getShiftListAsString(shift));
    }

}
