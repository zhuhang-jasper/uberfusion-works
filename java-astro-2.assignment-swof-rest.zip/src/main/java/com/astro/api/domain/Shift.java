package com.astro.api.domain;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class Shift {

    private int shiftNumber;
    private List<Employee> dutyOfTheShift;

    public Shift(int shiftNumber) {
        this.shiftNumber = shiftNumber;
    }

    public int getShiftNumber() {
        return shiftNumber;
    }

    public void setShiftNumber(int shiftNumber) {
        this.shiftNumber = shiftNumber;
    }

    public List<Employee> getDutyOfTheShift() {
        return dutyOfTheShift;
    }

    public void setDutyOfTheShift(List<Employee> employeeOnDuty) {
        this.dutyOfTheShift = employeeOnDuty;
    }

    @Override
    public String toString() {
        return String.format("Shift %d - %s", shiftNumber, Employee.getEmployeeListAsString(dutyOfTheShift));
    }

    public static String getShiftListAsString(List<Shift> list) {
        return list.stream().map(c -> String.valueOf(c)).collect(Collectors.joining(", "));
    }
}
