package com.astro.api.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class WeeklySchedule {

    private int weekNumber;
    private List<DailySchedule> dailySchedule;

    public WeeklySchedule() {
        this.dailySchedule = new ArrayList<DailySchedule>();
    }

    public int getWeekNumber() {
        return weekNumber;
    }

    public void setWeekNumber(int number) {
        this.weekNumber = number;
    }

    public List<DailySchedule> getDailySchedule() {
        return dailySchedule;
    }

    public void setDailySchedule(List<DailySchedule> dailySchedule) {
        this.dailySchedule = dailySchedule;
    }

    @Override
    public String toString() {
        return this.dailySchedule.stream().map(c -> String.valueOf(c)).collect(Collectors.joining("\n"));
    }

}
