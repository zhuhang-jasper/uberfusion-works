package com.astro.api.domain;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class Employee {

    private int empId;
    private String empName;

    public Employee(int empId) {
        this.empId = empId;
        this.empName = "Employee";
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    @Override
    public String toString() {
        return String.format("[Id: %s]", empId);
    }

    public static String getEmployeeListAsString(List<Employee> list) {
        return list.stream().map(c -> String.valueOf(c)).collect(Collectors.joining(","));
    }
}
