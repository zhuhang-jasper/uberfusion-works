package com.astro.api.common.util;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class StringUtil {

    public static boolean isNotNullAndEmpty(String input) {
        if (input == null) {
            return false;
        } else if (input.isEmpty() == true) {
            return false;
        }
        return true;
    }

}
