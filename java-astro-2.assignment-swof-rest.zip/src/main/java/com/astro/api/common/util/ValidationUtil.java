package com.astro.api.common.util;

import java.text.SimpleDateFormat;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class ValidationUtil {

    public static boolean isLengthWithin(String value, int min, int max) {

        boolean result = false;

        if (value.length() >= min && value.length() <= max) {
            result = true;
        }

        return result;
    }

    public static boolean isBoolean(String value) {

        boolean result = false;

        try {
            Boolean.parseBoolean(value);
            result = true;

        } catch (Exception e) {
            result = false;
        }

        return result;
    }

    public static boolean isInteger(String value) {

        boolean result = false;

        try {
            Integer.parseInt(value);
            result = true;

        } catch (Exception e) {
            result = false;
        }

        return result;
    }

    public static boolean isValidDate(String value, String format) {

        boolean result = false;

        if (value == null) {
            return false;
        }

        // setp: verify the date format here
        if (!StringUtil.isNotNullAndEmpty(format)) {
            return false;
        } else {

            try {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
                simpleDateFormat.setLenient(false);
                simpleDateFormat.parse(value);
                result = true;

            } catch (Exception e) {
                result = false;
            }

        }

        return result;
    }

}
