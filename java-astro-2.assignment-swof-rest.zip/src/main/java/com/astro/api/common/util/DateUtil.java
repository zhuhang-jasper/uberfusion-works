package com.astro.api.common.util;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class DateUtil {

    public static final String FT_YYYYMMDD_HHMISS = "yyyy-MM-dd HH:mm:ss";
    public static final String FT_YYYYMMDD_HHMISS_DIGIT = "yyyyMMddHHmmss";
    public static final String FT_DDMMYYYY_HHMISS = "dd-MM-yyyy HH:mm:ss";
    public static final String FT_DDMMMYYYY_HHMISS = "dd-MMM-yyyy HH:mm:ss";
    public static final String FT_DDMMYYYYHHMISS = "ddMMyyyyHHmmss";
    public static final String FT_DDMMYYYY_SLASH = "dd/MM/yyyy";
    public static final String FT_DDMMYYYY_DASH = "dd-MM-yyyy";
    public static final String FT_DDMMMYYYY = "dd-MMM-yyyy";
    public static final String FT_EEEDDMMMYYYY = "EEE, dd-MMM-yyyy";
    public static final String FT_MMMYYYY = "MMM yyyy";

    public static Date fromStringToDate(String format, String dateStr) {
        DateTimeFormatter fmt = DateTimeFormat.forPattern(format);

        Date result = null;
        if (dateStr == null) {
            // do nothing
        } else if (dateStr.trim().length() == 0) {
            // do nothing
        } else {

            // step: due to possible the incoming date like 5-4-28 12:00:00.0 (unknow extra .x at behind return from their ejb call)

            if (!format.contains(".")) {

                if (dateStr.contains(".")) {
                    dateStr = dateStr.substring(0, dateStr.indexOf("."));
                }

            }

            result = fmt.parseDateTime(dateStr).toDate();
        }

        return result;
    }

    public static String fromDateToString(String format, Date date) {
        DateTimeFormatter fmt = DateTimeFormat.forPattern(format);
        return fmt.print(new DateTime(date));
    }

    /**
     * Add or subtract days from a given date.
     * @param date The date to be modified
     * @param days Amount of days to be added. Negative value for subtraction
     * @return New date after math
     */
    public static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); // minus number would decrement the days
        return cal.getTime();
    }

    /**
     * Check if input date is a weekend (Saturday or Sunday)
     * @param date The date to be checked
     * @return Boolean value
     */
    public static boolean isWeekend(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ||
                cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            return true;
        }
        return false;
    }

    /**
     * Check if input date is a day of week inside the list
     * @param date The date to be checked
     * @return Boolean value
     */
    public static boolean isDayInList(Date date, List<Integer> dayList) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (dayList.contains(cal.get(Calendar.DAY_OF_WEEK))) {
            return true;
        }
        return false;
    }

    /**
     * Returns date of nearest upcoming Monday. If input date is already Monday, the next Monday will be returned.
     * @param date The date to be checked
     * @return The date of nearest Monday
     */
    public static Date nextMonday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
            return addDays(date, 7);
        } else {
            while (cal.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
                cal.add(Calendar.DATE, 1);
            }
            return cal.getTime();
        }
    }

    // testing
    public static void main(String[] args) {
        Date now = new Date();
        now = addDays(now, 2);
        System.out.println(fromDateToString(FT_DDMMMYYYY, nextMonday(now)));
    }

}
