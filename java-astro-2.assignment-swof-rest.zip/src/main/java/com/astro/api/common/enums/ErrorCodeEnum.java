package com.astro.api.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public enum ErrorCodeEnum {

    MISSING_INPUT("01", "Missing Input Field for '%s'"),
    INVALID_INPUT("02", "Unexpected Input Value for '%s'"),
    ILLEGAL_INPUT("03", "Illegal Input Value for '%s'"),
    SYSTEM_ERROR("05", "Some problem occured");

    private String errCode;
    private String errDesc;

    private ErrorCodeEnum(String errorCode, String errorMessage) {
        this.errCode = errorCode;
        this.errDesc = errorMessage;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errorCode) {
        this.errCode = errorCode;
    }

    public String getErrDesc() {
        return errDesc;
    }

    public void setErrDesc(String errorMessage) {
        this.errDesc = errorMessage;
    }

    private static final Map<String, ErrorCodeEnum> directoryValue;

    static {
        directoryValue = new LinkedHashMap<String, ErrorCodeEnum>();
        for (ErrorCodeEnum em : ErrorCodeEnum.values()) {
            directoryValue.put(em.getErrCode(), em);
        }
    }

    public static ErrorCodeEnum fromErrorCode(String errCode) {
        return directoryValue.get(errCode);
    }

}
