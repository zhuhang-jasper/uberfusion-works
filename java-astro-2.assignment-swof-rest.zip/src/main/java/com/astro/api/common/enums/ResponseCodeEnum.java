package com.astro.api.common.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public enum ResponseCodeEnum {

    SUCCESS("AA", "Success"),
    FAILED("AB", "Failed");

    private String resultCode;
    private String description;

    private ResponseCodeEnum(String resultCode, String description) {
        this.resultCode = resultCode;
        this.description = description;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private static final Map<String, ResponseCodeEnum> directoryValue;

    static {
        directoryValue = new LinkedHashMap<String, ResponseCodeEnum>();
        for (ResponseCodeEnum em : ResponseCodeEnum.values()) {
            directoryValue.put(em.getResultCode(), em);
        }
    }

    public static ResponseCodeEnum fromResultCode(String resultCode) {
        return directoryValue.get(resultCode);
    }

}
