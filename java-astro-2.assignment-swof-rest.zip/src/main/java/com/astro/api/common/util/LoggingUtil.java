package com.astro.api.common.util;

import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class LoggingUtil {

    public static Throwable getThrowableRootCause(Throwable e) {
        return ExceptionUtils.getThrowables(e)[ExceptionUtils.getThrowableCount(e) - 1];
    }

}
