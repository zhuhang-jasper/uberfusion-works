package com.astro.api.rest;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class ScheduleRequestBody extends RestRequestBody {

    private String startDate;
    private String noOfWeeks;
    private String evenDistribution;
    private String totalEmployees;
    private String shiftPerDay;
    private String employeePerShift;
    private String bizDays;
    private String isBizMon;
    private String isBizTue;
    private String isBizWed;
    private String isBizThu;
    private String isBizFri;
    private String isBizSat;
    private String isBizSun;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getNoOfWeeks() {
        return noOfWeeks;
    }

    public void setNoOfWeeks(String noOfWeeks) {
        this.noOfWeeks = noOfWeeks;
    }

    public String getEvenDistribution() {
        return evenDistribution;
    }

    public void setEvenDistribution(String evenDistribution) {
        this.evenDistribution = evenDistribution;
    }

    public String getTotalEmployees() {
        return totalEmployees;
    }

    public void setTotalEmployees(String totalEmployees) {
        this.totalEmployees = totalEmployees;
    }

    public String getShiftPerDay() {
        return shiftPerDay;
    }

    public void setShiftPerDay(String shiftPerDay) {
        this.shiftPerDay = shiftPerDay;
    }

    public String getEmployeePerShift() {
        return employeePerShift;
    }

    public void setEmployeePerShift(String employeePerShift) {
        this.employeePerShift = employeePerShift;
    }

    public String getBizDays() {
        return bizDays;
    }

    public void setBizDays(String bizDays) {
        this.bizDays = bizDays;
    }

    public String getIsBizMon() {
        return isBizMon;
    }

    public void setIsBizMon(String isBizMon) {
        this.isBizMon = isBizMon;
    }

    public String getIsBizTue() {
        return isBizTue;
    }

    public void setIsBizTue(String isBizTue) {
        this.isBizTue = isBizTue;
    }

    public String getIsBizWed() {
        return isBizWed;
    }

    public void setIsBizWed(String isBizWed) {
        this.isBizWed = isBizWed;
    }

    public String getIsBizThu() {
        return isBizThu;
    }

    public void setIsBizThu(String isBizThu) {
        this.isBizThu = isBizThu;
    }

    public String getIsBizFri() {
        return isBizFri;
    }

    public void setIsBizFri(String isBizFri) {
        this.isBizFri = isBizFri;
    }

    public String getIsBizSat() {
        return isBizSat;
    }

    public void setIsBizSat(String isBizSat) {
        this.isBizSat = isBizSat;
    }

    public String getIsBizSun() {
        return isBizSun;
    }

    public void setIsBizSun(String isBizSun) {
        this.isBizSun = isBizSun;
    }

}
