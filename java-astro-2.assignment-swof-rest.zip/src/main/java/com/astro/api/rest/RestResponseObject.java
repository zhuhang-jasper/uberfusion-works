package com.astro.api.rest;

import java.io.Serializable;

import com.astro.api.common.enums.ErrorCodeEnum;
import com.astro.api.common.enums.ResponseCodeEnum;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class RestResponseObject implements Serializable {

    @ApiModelProperty(notes = "Response Code", allowableValues = "AA,AB")
    private String responseCode;

    @ApiModelProperty(notes = "Error Code", allowableValues = "01,02,03,05")
    private String errCode;

    @ApiModelProperty(notes = "Error Description")
    private String errDesc;

    @ApiModelProperty(notes = "Request object")
    private RestRequestBody request;

    @ApiModelProperty(notes = "Response object")
    private RestResponseBody body;

    public RestResponseObject() {
        this.responseCode = ResponseCodeEnum.FAILED.getResultCode();
        this.errCode = "";
        this.errDesc = "";
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String resultCode) {
        this.responseCode = resultCode;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrDesc() {
        return errDesc;
    }

    public void setErrDesc(String errMsg) {
        this.errDesc = errMsg;
    }

    public RestRequestBody getRequest() {
        return request;
    }

    public void setRequest(RestRequestBody request) {
        this.request = request;
    }

    public RestResponseBody getBody() {
        return body;
    }

    public void setBody(RestResponseBody body) {
        this.body = body;
    }

    public RestResponseObject initError(ErrorCodeEnum error) {
        this.responseCode = ResponseCodeEnum.SUCCESS.getResultCode();
        this.errCode = error.getErrCode();
        this.errDesc = error.getErrDesc();
        return this;
    }

    public RestResponseObject initError(ErrorCodeEnum error, String errorDesc) {
        this.responseCode = ResponseCodeEnum.SUCCESS.getResultCode();
        this.errCode = error.getErrCode();
        this.errDesc = errorDesc;
        return this;
    }

    public RestResponseObject initErrorForField(ErrorCodeEnum error, String fieldName) {
        this.responseCode = ResponseCodeEnum.SUCCESS.getResultCode();
        this.errCode = error.getErrCode();
        this.errDesc = String.format(error.getErrDesc(), fieldName);
        return this;
    }

}
