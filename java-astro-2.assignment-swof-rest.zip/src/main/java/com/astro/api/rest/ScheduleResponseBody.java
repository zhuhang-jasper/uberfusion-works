package com.astro.api.rest;

import java.util.ArrayList;
import java.util.List;

import com.astro.api.domain.WeeklySchedule;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class ScheduleResponseBody extends RestResponseBody {

    private int maxShiftsPerEmp;
    private List<WeeklySchedule> schedule;

    public ScheduleResponseBody() {
        super();
        this.schedule = new ArrayList<WeeklySchedule>();
    }

    public int getMaxShiftsPerEmp() {
        return maxShiftsPerEmp;
    }

    public void setMaxShiftsPerEmp(int maxShiftsPerEmp) {
        this.maxShiftsPerEmp = maxShiftsPerEmp;
    }

    public List<WeeklySchedule> getSchedule() {
        return schedule;
    }

    public void setSchedule(List<WeeklySchedule> schedule) {
        this.schedule = schedule;
    }

}
