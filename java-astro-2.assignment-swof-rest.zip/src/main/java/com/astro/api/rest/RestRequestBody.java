package com.astro.api.rest;

import java.io.Serializable;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public abstract class RestRequestBody implements Serializable {

}
