package com.astro.api.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SpringFoxConfig {

    @Bean
    public Docket apiDocket() {
        ArrayList<ResponseMessage> standardExpectedHttpResponses = createStandardExpectedHttpResponses();

        return new Docket(DocumentationType.SWAGGER_2)
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET,
                        standardExpectedHttpResponses)
                .globalResponseMessage(RequestMethod.POST,
                        standardExpectedHttpResponses)
                .globalResponseMessage(RequestMethod.PUT,
                        standardExpectedHttpResponses)
                .globalResponseMessage(RequestMethod.DELETE,
                        standardExpectedHttpResponses)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.astro.api"))
                .paths(PathSelectors.ant("/swof-api"))
                .build()
                .apiInfo(getApiInfo())
                .protocols(protocols());
    }

    private ArrayList<ResponseMessage> createStandardExpectedHttpResponses() {
        ArrayList<ResponseMessage> messages = new ArrayList<ResponseMessage>();

        messages.add(new ResponseMessageBuilder().code(200).message("Ok").build());
        messages.add(new ResponseMessageBuilder().code(400).message("Bad Request").build());
        messages.add(new ResponseMessageBuilder().code(401).message("Unauthorized").build());
        messages.add(new ResponseMessageBuilder().code(403).message("Forbidden").build());
        messages.add(new ResponseMessageBuilder().code(404).message("Not Found").build());
        messages.add(new ResponseMessageBuilder().code(500).message("Internal Server Error").build());

        return messages;
    }

    private ApiInfo getApiInfo() {
        return new ApiInfo(
                "Astro SWOF REST API",
                "A RESTful web service to generate 'Spin Wheel of Fate' schedule.",
                "1.0.0",
                null,
                new Contact("Developer", "", "zhuhang.loo@uberfusion.com"),
                null,
                null,
                Collections.emptyList());
    }

    private Set<String> protocols() {
        final Set<String> protocolSet = new HashSet<>();
        protocolSet.add("http");
        protocolSet.add("https");
        return protocolSet;
    }

}
