package com.astro.api.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.astro.api.common.enums.ErrorCodeEnum;
import com.astro.api.common.enums.ResponseCodeEnum;
import com.astro.api.common.util.DateUtil;
import com.astro.api.common.util.LoggingUtil;
import com.astro.api.common.util.StringUtil;
import com.astro.api.common.util.ValidationUtil;
import com.astro.api.rest.RestResponseObject;
import com.astro.api.rest.ScheduleRequestBody;
import com.astro.api.rest.ScheduleResponseBody;
import com.astro.api.service.SchedulerService;
import com.astro.api.service.request.GenerateScheduleRequest;
import com.astro.api.service.response.GenerateScheduleResponse;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * @author UF-LooZhuHang(Jasper)
 */
@RestController
public class ScheduleController extends BaseController {

    @Autowired
    private SchedulerService schedulerService;

    private static final String postDateFormat = DateUtil.FT_DDMMYYYY_SLASH;

    @CrossOrigin
    @ApiOperation(value = "Generate SWOF schedule", response = RestResponseObject.class)
    @GetMapping("/swof-api")
    public RestResponseObject generateSwofSchedule(
            @ApiParam(value = "Start date of schedule") @RequestParam(defaultValue = "") String startDate,
            @ApiParam(value = "Total weeks to generate schedule") @RequestParam(value = "noOfWeeks", defaultValue = "2") String noOfWeeks,
            @ApiParam(value = "Try to schedule everyone with equal no of shifts, and sort unassigned employees first."
                    + "<br>Eg: Invoke API with all default parameters, All employees will work only once a week. "
                    + "None will have all their shifts scheduled in the same week.") @RequestParam(value = "evenDistribution", defaultValue = "false") String evenDistribution,
            @ApiParam(value = "Total employees to put in support wheel.") @RequestParam(value = "totalEmployees", defaultValue = "10") String totalEmployees,
            @ApiParam(value = "Total shifts per day") @RequestParam(value = "shiftPerDay", defaultValue = "2") String shiftPerDay,
            @ApiParam(value = "Total employees per shift") @RequestParam(value = "employeePerShift", defaultValue = "1") String employeePerShift,
            @ApiParam(value = "Business days to be included in schedule."
                    + "<br>'bank' : Mon-Fri"
                    + "<br>'custom' : use paramters > isBizMon ... isBizSun", allowableValues = "bank,custom") @RequestParam(value = "bizDays", defaultValue = "bank") String bizDays,
            @ApiParam(value = "Specify if Monday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizMon", defaultValue = "true") String isBizMon,
            @ApiParam(value = "Specify if Tuesday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizTue", defaultValue = "true") String isBizTue,
            @ApiParam(value = "Specify if Wednesday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizWed", defaultValue = "true") String isBizWed,
            @ApiParam(value = "Specify if Thursday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizThu", defaultValue = "true") String isBizThu,
            @ApiParam(value = "Specify if Friday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizFri", defaultValue = "true") String isBizFri,
            @ApiParam(value = "Specify if Saturday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizSat", defaultValue = "false") String isBizSat,
            @ApiParam(value = "Specify if Sunday is working day. Used when bizDays set to 'custom'") @RequestParam(value = "isBizSun", defaultValue = "false") String isBizSun) {

        RestResponseObject restResponse = new RestResponseObject();
        ScheduleResponseBody responseBody = new ScheduleResponseBody();

        //map request body
        ScheduleRequestBody requestBody = new ScheduleRequestBody();
        requestBody.setStartDate(startDate);
        requestBody.setNoOfWeeks(noOfWeeks);
        requestBody.setEvenDistribution(evenDistribution);
        requestBody.setTotalEmployees(totalEmployees);
        requestBody.setShiftPerDay(shiftPerDay);
        requestBody.setEmployeePerShift(employeePerShift);
        requestBody.setBizDays(bizDays);
        requestBody.setIsBizMon(isBizMon);
        requestBody.setIsBizTue(isBizTue);
        requestBody.setIsBizWed(isBizWed);
        requestBody.setIsBizThu(isBizThu);
        requestBody.setIsBizFri(isBizFri);
        requestBody.setIsBizSat(isBizSat);
        requestBody.setIsBizSun(isBizSun);
        restResponse.setRequest(requestBody);

        //validate input parameters
        if (!StringUtil.isNotNullAndEmpty(startDate)) {
            startDate = DateUtil.fromDateToString(DateUtil.FT_DDMMYYYY_SLASH, new Date());
        }
        if (!ValidationUtil.isValidDate(startDate, DateUtil.FT_DDMMYYYY_SLASH)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "startDate");
        } else if (!ValidationUtil.isInteger(noOfWeeks)
                || Integer.parseInt(noOfWeeks) == 0
                || !ValidationUtil.isLengthWithin(noOfWeeks, 1, 2)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "noOfWeeks");
        } else if (!ValidationUtil.isBoolean(evenDistribution)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "evenDistribution");
        } else if (!ValidationUtil.isInteger(totalEmployees)
                || Integer.parseInt(totalEmployees) == 0
                || !ValidationUtil.isLengthWithin(noOfWeeks, 1, 3)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "totalEmployees");
        } else if (!ValidationUtil.isInteger(shiftPerDay)
                || Integer.parseInt(shiftPerDay) == 0
                || !ValidationUtil.isLengthWithin(noOfWeeks, 1, 2)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "shiftPerDay");
        } else if (!ValidationUtil.isInteger(employeePerShift)
                || Integer.parseInt(employeePerShift) == 0
                || !ValidationUtil.isLengthWithin(noOfWeeks, 1, 2)) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "employeePerShift");
        } else if (!bizDays.equalsIgnoreCase("bank") && !bizDays.equalsIgnoreCase("custom")) {
            return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "bizDays");
        }

        //configuring business days
        List<Integer> businessDays = new ArrayList<Integer>();
        if (bizDays.equalsIgnoreCase("custom")) {
            boolean check = ValidationUtil.isBoolean(isBizMon)
                    && ValidationUtil.isBoolean(isBizTue)
                    && ValidationUtil.isBoolean(isBizWed)
                    && ValidationUtil.isBoolean(isBizThu)
                    && ValidationUtil.isBoolean(isBizFri)
                    && ValidationUtil.isBoolean(isBizSat)
                    && ValidationUtil.isBoolean(isBizSun);
            if (!check) {
                return restResponse.initErrorForField(ErrorCodeEnum.INVALID_INPUT, "isBiz___");
            }

            if (Boolean.parseBoolean(isBizMon)) {
                businessDays.add(Calendar.MONDAY);
            }
            if (Boolean.parseBoolean(isBizTue)) {
                businessDays.add(Calendar.TUESDAY);
            }
            if (Boolean.parseBoolean(isBizWed)) {
                businessDays.add(Calendar.WEDNESDAY);
            }
            if (Boolean.parseBoolean(isBizThu)) {
                businessDays.add(Calendar.THURSDAY);
            }
            if (Boolean.parseBoolean(isBizFri)) {
                businessDays.add(Calendar.FRIDAY);
            }
            if (Boolean.parseBoolean(isBizSat)) {
                businessDays.add(Calendar.SATURDAY);
            }
            if (Boolean.parseBoolean(isBizSun)) {
                businessDays.add(Calendar.SUNDAY);
            }

        } else if (bizDays.equalsIgnoreCase("bank")) {
            businessDays.add(Calendar.MONDAY);
            businessDays.add(Calendar.TUESDAY);
            businessDays.add(Calendar.WEDNESDAY);
            businessDays.add(Calendar.THURSDAY);
            businessDays.add(Calendar.FRIDAY);
        }

        if (Integer.parseInt(totalEmployees) < 2 * Integer.parseInt(shiftPerDay) * Integer.parseInt(employeePerShift)) {
            int min = 2 * Integer.parseInt(shiftPerDay) * Integer.parseInt(employeePerShift);
            return restResponse.initError(ErrorCodeEnum.ILLEGAL_INPUT, "Total employees cannot support business rules. Must be enough for two business days. (" + min + " employee)");
        }

        //init service request
        GenerateScheduleRequest serviceRequest = new GenerateScheduleRequest();
        serviceRequest.setStartDate(DateUtil.fromStringToDate(postDateFormat, startDate));
        serviceRequest.setNoOfWeeks(Integer.parseInt(noOfWeeks));
        serviceRequest.setEvenDistribution(Boolean.parseBoolean(evenDistribution));
        serviceRequest.setTotalEmployees(Integer.parseInt(totalEmployees));
        serviceRequest.setShiftPerDay(Integer.parseInt(shiftPerDay));
        serviceRequest.setEmployeePerShift(Integer.parseInt(employeePerShift));
        serviceRequest.setBusinessDays(businessDays);

        //call service
        GenerateScheduleResponse serviceResponse = schedulerService.generateSchedule(serviceRequest);

        if (serviceResponse.getException() != null) {
            LoggingUtil.getThrowableRootCause(serviceResponse.getException()).printStackTrace();

            restResponse.setErrCode(ErrorCodeEnum.SYSTEM_ERROR.getErrCode());

            Throwable t = serviceResponse.getException();
            if (t instanceof IllegalArgumentException && t.getMessage().contains("bound must be positive")) {
                restResponse.setErrDesc("Not enough employees to assign.");
            } else {
                restResponse.setErrDesc(t.getMessage());
            }

            return restResponse;
        }

        responseBody = serviceResponse.getSwofSchedule();
        restResponse.setResponseCode(ResponseCodeEnum.SUCCESS.getResultCode());
        restResponse.setBody(responseBody);

        return restResponse;
    }

}
