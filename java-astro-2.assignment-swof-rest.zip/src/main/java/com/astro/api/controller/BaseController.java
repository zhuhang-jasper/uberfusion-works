package com.astro.api.controller;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class BaseController {

}
