package com.astro.api.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.astro.api.common.util.DateUtil;
import com.astro.api.domain.DailySchedule;
import com.astro.api.domain.Employee;
import com.astro.api.domain.Shift;
import com.astro.api.domain.WeeklySchedule;
import com.astro.api.rest.ScheduleResponseBody;
import com.astro.api.service.SchedulerService;
import com.astro.api.service.request.GenerateScheduleRequest;
import com.astro.api.service.response.GenerateScheduleResponse;

/**
 * @author UF-LooZhuHang(Jasper)
 */
@Service
public class SchedulerServiceImpl implements SchedulerService {

    @Override
    public GenerateScheduleResponse generateSchedule(GenerateScheduleRequest request) {

        GenerateScheduleResponse response = new GenerateScheduleResponse();

        try {

            //configuration
            Date dateOfSchedule = request.getStartDate();
            int noOfWeeks = request.getNoOfWeeks();
            boolean evenDistribution = request.getEvenDistribution();
            int totalEmployees = request.getTotalEmployees();
            int shiftPerDay = request.getShiftPerDay();
            int employeePerShift = request.getEmployeePerShift();
            int businessDayPerWeek = request.getBusinessDays().size();
            List<Integer> businessDays = request.getBusinessDays();

            List<WeeklySchedule> finalSchedule = new ArrayList<WeeklySchedule>();
            Map<Employee, Integer> workingShifts = new HashMap<Employee, Integer>();

            //prepare employee pool
            List<Employee> employee = new ArrayList<Employee>();
            for (int i = 0; i < totalEmployees; i++) {
                Employee temp = new Employee(i + 1);
                employee.add(temp);
                workingShifts.put(temp, 0);
            }

            List<Employee> drawingPool = new ArrayList<Employee>(employee);
            List<Employee> priorityPool = new ArrayList<Employee>();
            List<Employee> waitingPool = new ArrayList<Employee>();
            List<Employee> preDrawingPool = new ArrayList<Employee>();

            //calculate maximum shifts allowed per employee to ensure no one is left out
            double calc = (double) noOfWeeks * (double) businessDayPerWeek
                    * shiftPerDay * employeePerShift / totalEmployees;
            int maxShiftsPerEmp = (int) Math.ceil(calc);

            //            System.out.println("calc="+calc+",max=" + maxShiftsPerEmp);

            for (int w = 0; w < noOfWeeks; w++) {
                System.out.println("---start of new week " + (w + 1) + "---");
                //step: generate schedule week by week
                WeeklySchedule weekSchd = new WeeklySchedule();
                weekSchd.setWeekNumber(w + 1);

                for (int d = 0; d < businessDayPerWeek; d++) {

                    //                    if (DateUtil.isWeekend(dateOfSchedule)) {
                    //                        dateOfSchedule = DateUtil.nextMonday(dateOfSchedule);
                    //                    }
                    while (!DateUtil.isDayInList(dateOfSchedule, businessDays)) {
                        dateOfSchedule = DateUtil.addDays(dateOfSchedule, 1);
                    }

                    //step: populate schedule day by day
                    DailySchedule daySchd = new DailySchedule(DateUtil.fromDateToString(DateUtil.FT_EEEDDMMMYYYY, dateOfSchedule));

                    List<Shift> shifts = new ArrayList<Shift>();
                    List<Employee> dutyOfTheDay = new ArrayList<Employee>();

                    for (int s = 0; s < shiftPerDay; s++) {

                        Shift shift = new Shift(s + 1);
                        List<Employee> dutyOfTheShift = new ArrayList<Employee>();

                        for (int e = 0; e < employeePerShift; e++) {

                            Employee selected = null;
                            if (priorityPool.size() > 0) {
                                selected = priorityPool.get(new Random().nextInt(priorityPool.size()));
                            } else {
                                selected = drawingPool.get(new Random().nextInt(drawingPool.size()));
                            }

                            //check if reached maximum shifts allowed
                            int shiftCount = 0;
                            if (workingShifts.get(selected) != null) {
                                shiftCount = workingShifts.get(selected);
                            }
                            workingShifts.put(selected, ++shiftCount);
                            if (shiftCount < maxShiftsPerEmp) {
                                //move to waiting list for redraw later
                                if (!evenDistribution) {
                                    waitingPool.add(selected);
                                }
                            }

                            dutyOfTheShift.add(selected);
                            priorityPool.remove(selected);
                            if (!drawingPool.remove(selected)) {
                                throw new Exception("Selected employee not in drawing pool!");
                            }
                            //(even distribute) put duplicate employee to waiting pool
                            if (evenDistribution && drawingPool.remove(selected)) {
                                waitingPool.add(selected);
                            }

                        }

                        dutyOfTheDay.addAll(dutyOfTheShift);
                        shift.setDutyOfTheShift(dutyOfTheShift);
                        shifts.add(shift);

                    }

                    dateOfSchedule = DateUtil.addDays(dateOfSchedule, 1);

                    //step: prepare pool for next scheduling day
                    if (preDrawingPool.size() > 0) {
                        //add back employees to pool
                        drawingPool.addAll(preDrawingPool);
                        preDrawingPool.clear();
                    }
                    if (waitingPool.size() > 0) {
                        //only wait for one working day
                        preDrawingPool.addAll(waitingPool);
                        waitingPool.clear();
                    }

                    if (!evenDistribution) {
                        if (drawingPool.size() < shiftPerDay * employeePerShift) {
                            //exception: run out of employee before last day
                            if (d + 1 != businessDayPerWeek || w + 1 != noOfWeeks) {
                                System.out.println("****EXCEPTION INCOMING**** " + drawingPool.size() + "<" + shiftPerDay);
                                throw new Exception("potential logic problem by developer");
                            }
                        }

                        /* MOVED: PRIORITY POOL REBUILD CHANGED FROM WEEKLY TO DAILY BASIS */
                        //avoid the same employee unselected too frequent that causes employee shortage near end of schedule
                        Map<Employee, Integer> temp = new HashMap<Employee, Integer>(workingShifts);
                        for (Employee emp : preDrawingPool) {
                            temp.remove(emp);
                        }
                        List<Employee> least = getLeastAssignedEmployee(temp, maxShiftsPerEmp, shiftPerDay * employeePerShift);
                        priorityPool.clear();
                        priorityPool.addAll(least);
                        //                    priorityPool.removeAll(preDrawingPool);

                    } else {
                        //exception: run out of employee at start of week
                        if (preDrawingPool.size() > 0 && drawingPool.size() < shiftPerDay* employeePerShift) {
                            throw new Exception("potential logic problem by developer");
                        } else if (preDrawingPool.size() == 0 && drawingPool.size() < shiftPerDay * employeePerShift) {
                            //form new pool for next cycle of scheduling
                            priorityPool.addAll(drawingPool);
                            //drawingPool.clear(); //intentionally duplicate employee in drawing pool
                            drawingPool.addAll(employee);
                            drawingPool.removeAll(dutyOfTheDay);
                            preDrawingPool.addAll(dutyOfTheDay);
                        }
                    }

                    daySchd.setShift(shifts);
                    weekSchd.getDailySchedule().add(daySchd);

                }
                if (!evenDistribution) {
                    /* PRIORITY POOL REBUILD ON WEEKLY BASIS */
                }
                finalSchedule.add(weekSchd);

                System.out.println(weekSchd);
                System.out.println("  priority pool:" + Employee.getEmployeeListAsString(priorityPool));
                System.out.println("  draw pool:" + Employee.getEmployeeListAsString(drawingPool));
                System.out.println("  wait pool:" + Employee.getEmployeeListAsString(waitingPool));
                System.out.println("  predraw pool:" + Employee.getEmployeeListAsString(preDrawingPool));
                System.out.print("  shifts:");
                Iterator<Entry<Employee, Integer>> it = workingShifts.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<Employee, Integer> pair = (Map.Entry<Employee, Integer>) it.next();
                    Employee key = pair.getKey();
                    int val = pair.getValue();
                    System.out.print(key+"#"+val+", ");
                }
                System.out.println();

            }

            //set REST response body
            ScheduleResponseBody swofSchedule = new ScheduleResponseBody();
            swofSchedule.setMaxShiftsPerEmp(maxShiftsPerEmp);
            swofSchedule.setSchedule(finalSchedule);
            response.setSwofSchedule(swofSchedule);

        } catch (Exception e) {
            response.setException(e);
        }

        return response;
    }

    private static Employee getMinShift(Map<Employee, Integer> shifts, int maxFreqPerEmp) {
        Employee emp = null;
        Iterator<Entry<Employee, Integer>> it = shifts.entrySet().iterator();
        int leastFreq = maxFreqPerEmp;
        while (it.hasNext()) {
            Map.Entry<Employee, Integer> pair = it.next();
            int freq = pair.getValue();
            if (freq < leastFreq) {
                leastFreq = freq;
                emp = pair.getKey();
            }
        }
        return emp;
    }

    private static List<Employee> getLeastAssignedEmployee(Map<Employee, Integer> shifts, int maxFreqPerEmp, int empPerDay) {

        Map<Employee, Integer> temp = new HashMap<Employee, Integer>(shifts);
        List<Employee> least = new ArrayList<Employee>();
        while (least.size() < empPerDay) {
            Employee added = getMinShift(temp, maxFreqPerEmp);
            if (added == null) {
                break;
            }
            least.add(added);
            temp.remove(added);
        }

        //        if (leastFreq < maxFreqPerEmp) {
        //            Iterator<Entry<Employee, Integer>> it2 = shifts.entrySet().iterator();
        //            while (it2.hasNext()) {
        //                Map.Entry<Employee, Integer> pair = it2.next();
        //                Employee emp = pair.getKey();
        //                int freq = pair.getValue();
        //                if (freq == leastFreq) {
        //                    least.add(emp);
        //                }
        //            }
        //        }

        return least;
    }

    // testing
    public static void main(String[] args) {

        Map<Employee, Integer> workingShifts = new HashMap<Employee, Integer>();

        //prepare employee pool
        //        List<Employee> employee = new ArrayList<Employee>();
        //        for (int i = 0; i < 6; i++) {
        //            Employee temp = new Employee(i + 1);
        //            employee.add(temp);
        //            workingShifts.put(temp, 0);
        //        }

        Employee emp1 = new Employee(1);
        workingShifts.put(emp1, 10);
        Employee emp2 = new Employee(2);
        workingShifts.put(emp2, 1);
        Employee emp3 = new Employee(3);
        workingShifts.put(emp3, 2);
        Employee emp4 = new Employee(4);
        workingShifts.put(emp4, 5);
        Employee emp5 = new Employee(5);
        workingShifts.put(emp5, 6);
        Employee emp6 = new Employee(6);
        workingShifts.put(emp6, 1);

        List<Employee> least = getLeastAssignedEmployee(workingShifts, 130, 3 * 1);

        System.out.println("  least pool:" + Employee.getEmployeeListAsString(least));

    }

    public static void testController(String[] args) {

        //init service request
        GenerateScheduleRequest serviceRequest = new GenerateScheduleRequest();
        serviceRequest.setStartDate(new Date());
        serviceRequest.setNoOfWeeks(52);
        serviceRequest.setEvenDistribution(false);
        serviceRequest.setTotalEmployees(6);
        serviceRequest.setShiftPerDay(3);
        serviceRequest.setEmployeePerShift(1);
        List<Integer> businessDays = new ArrayList<Integer>();
        businessDays.add(Calendar.MONDAY);
        businessDays.add(Calendar.TUESDAY);
        businessDays.add(Calendar.WEDNESDAY);
        businessDays.add(Calendar.THURSDAY);
        businessDays.add(Calendar.FRIDAY);
        serviceRequest.setBusinessDays(businessDays);

        //call service
        SchedulerService service = new SchedulerServiceImpl();
        GenerateScheduleResponse serviceResponse = service.generateSchedule(serviceRequest);
        if (serviceResponse.getException() != null) {
            serviceResponse.getException().printStackTrace();
        }

    }

}
