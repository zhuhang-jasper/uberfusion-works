package com.astro.api.service.response;

import java.io.Serializable;

import com.astro.api.rest.ScheduleResponseBody;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class GenerateScheduleResponse extends ResponseObject implements Serializable {

    private ScheduleResponseBody swofSchedule;

    public ScheduleResponseBody getSwofSchedule() {
        return swofSchedule;
    }

    public void setSwofSchedule(ScheduleResponseBody schedule) {
        this.swofSchedule = schedule;
    }

}
