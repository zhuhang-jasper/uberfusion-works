package com.astro.api.service.request;

import java.io.Serializable;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public abstract class RequestObject implements Serializable {

}
