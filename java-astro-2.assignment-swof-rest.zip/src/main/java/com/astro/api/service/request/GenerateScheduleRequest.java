package com.astro.api.service.request;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public class GenerateScheduleRequest extends RequestObject implements Serializable {

    private Date startDate;
    private int noOfWeeks;
    private boolean evenDistribution;
    private int totalEmployees;
    private int shiftPerDay;
    private int employeePerShift;
    private List<Integer> businessDays;

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date date) {
        this.startDate = date;
    }

    public int getNoOfWeeks() {
        return noOfWeeks;
    }

    public void setNoOfWeeks(int noOfWeeks) {
        this.noOfWeeks = noOfWeeks;
    }

    public boolean getEvenDistribution() {
        return evenDistribution;
    }

    public void setEvenDistribution(boolean evenDistribution) {
        this.evenDistribution = evenDistribution;
    }

    public int getTotalEmployees() {
        return totalEmployees;
    }

    public void setTotalEmployees(int totalEmployees) {
        this.totalEmployees = totalEmployees;
    }

    public int getShiftPerDay() {
        return shiftPerDay;
    }

    public void setShiftPerDay(int shiftPerDay) {
        this.shiftPerDay = shiftPerDay;
    }

    public int getEmployeePerShift() {
        return employeePerShift;
    }

    public void setEmployeePerShift(int employeePerShift) {
        this.employeePerShift = employeePerShift;
    }

    public List<Integer> getBusinessDays() {
        return businessDays;
    }

    public void setBusinessDays(List<Integer> businessDays) {
        this.businessDays = businessDays;
    }

}
