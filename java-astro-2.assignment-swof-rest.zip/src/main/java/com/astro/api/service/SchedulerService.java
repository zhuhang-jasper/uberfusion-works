package com.astro.api.service;

import com.astro.api.service.request.GenerateScheduleRequest;
import com.astro.api.service.response.GenerateScheduleResponse;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public interface SchedulerService {

    GenerateScheduleResponse generateSchedule(GenerateScheduleRequest generateScheduleRequest);

}
