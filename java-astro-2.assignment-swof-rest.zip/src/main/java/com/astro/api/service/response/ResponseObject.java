package com.astro.api.service.response;

import java.io.Serializable;

/**
 * @author UF-LooZhuHang(Jasper)
 */
public abstract class ResponseObject implements Serializable {

    private Exception exception;

    public Exception getException() {
        return exception;
    }

    public void setException(Exception exception) {
        this.exception = exception;
    }

}
