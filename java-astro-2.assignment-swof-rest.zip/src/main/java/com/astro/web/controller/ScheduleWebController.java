package com.astro.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author UF-LooZhuHang(Jasper)
 */
@Controller
public class ScheduleWebController {

    @RequestMapping("/swof")
    public String swofPage() {
        return "index.html";
    }

}
