/*
* Parse JSON object and return valid non-null object
* @param object, The input object
* @parm bool, Specify whether to remove null/blank objects
*/
function parseArray(object,bool) {

    /*//test - copy to html js
    debugger;
    var testArr1 = [{id: "aaa", pw: "aaa"},{id: "", pw: ""},{id: "", pw: ""},{id: "bbb", pw: "bbb"},{id: "ccc", pw: "ccc"},{id: "", pw: ""}];
    var testArr2 = ["","aaa","bbb","","","ccc",""];
    var test3 = {id: "aaa", pw: "aaa"};
    var test4 = "text";

    testArr1 = parseArray(testArr1,false);
    testArr2 = parseArray(testArr2);
    test3 = parseArray(test3);
    test4 = parseArray(test4);*/

    var obj = object || [];
    var filter = (bool != null) ? bool : true;

    if (!(obj instanceof Array))
        obj = $.makeArray(obj);
    obj = $.merge([],obj);

    if (obj.length > 0 && filter) {
        for(i = obj.length - 1; i > -1; i--) {
            var to_delete = false;
            if (obj[i] !== null) {
                if (typeof obj[i] === 'object') {
                    var keys = [], notnull = 0;
                    for (var key in obj[i]) {
                        if ( String(obj[i][key]).trim() != "")
                            notnull++;
                    }
                    if (notnull == 0)
                        to_delete = true;
                } else if (String(obj[i]).trim() == "")
                    to_delete = true;
            } else
                to_delete = true;
            if (to_delete)
                obj.splice(i,1);
        }
    }
    return obj;
}