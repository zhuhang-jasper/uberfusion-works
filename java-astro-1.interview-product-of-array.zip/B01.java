public class B01 {

    public static void asserting(/*@NonNull*/ int[] expected, /*@NonNull*/ int[] actual) {
        if (expected.length != actual.length) {
            throw new RuntimeException("mismatch length, expected=[" + expected.length + "] actual=[" + actual.length + "]");
        }
        for (int ix = 0; ix < expected.length; ix += 1) {
            if (expected[ix] != actual[ix]) {
                throw new RuntimeException("mismatch offset=[" + ix + "] expected=[" + expected[ix] + "] actual=[" + actual[ix] + "]");
            }
        }
    }

    public static void main(String[] args) {
        int[] input = { 1, 2, 4, 8, 16 };
        int[] expected = { 1024, 512, 256, 128, 64 };

        int len = input.length;
        int[] output = new int[len];

        int multiplyAllElement = 1;
        for (int i = 0; i < len; i++) {
            multiplyAllElement *= input[i];
        }

        for (int i = 0; i < len; i++) {
            output[i] = multiplyAllElement/input[i];
        }

        asserting(expected, output);
    }

}
