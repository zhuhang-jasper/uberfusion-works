public class B01 {

    public static void asserting(/*@NonNull*/ int[] expected, /*@NonNull*/ int[] actual) {
        if (expected.length != actual.length) {
            throw new RuntimeException("mismatch length, expected=[" + expected.length + "] actual=[" + actual.length + "]");
        }
        for (int ix = 0; ix < expected.length; ix += 1) {
            if (expected[ix] != actual[ix]) {
                throw new RuntimeException("mismatch offset=[" + ix + "] expected=[" + expected[ix] + "] actual=[" + actual[ix] + "]");
            }
        }
    }

    public static void main(String[] args) {
        int[] input = { 1, 0, 4, 8, 16 };
//        int[] expected = { 1024, 512, 256, 128, 64 };
        int[] expected = { 0, 512, 0, 0, 0 };

        int len = input.length;
        int[] output = new int[len];

        int multiplyAllElement = 1;
        int zeroValueOccurence = 0;
        int indexOfFirstZeroValue = -1;
        for (int i = 0; i < len; i++) {
            if (input[i] != 0) {
                multiplyAllElement *= input[i];
            } else if (++zeroValueOccurence > 1) {
                // more than 2 zero elements = all output are zeroes
                multiplyAllElement = 0;
                break;
            } else {
                indexOfFirstZeroValue = i;
            }
        }

        for (int i = 0; i < len; i++) {
            if (multiplyAllElement == 0)
                output[i] = 0;
            else if (i == indexOfFirstZeroValue)
                output[i] = multiplyAllElement;
            else {
                // if zero element exists, all output of non-zero elements will be 0
                if (indexOfFirstZeroValue > -1)
                    output[i] = 0; 
                else
                    output[i] = multiplyAllElement/input[i];
            }
        }

        asserting(expected, output);
//        for (int i = 0; i < len; i++) {
//            System.out.print(output[i] + ((i == len - 1)? "" : ","));
//        }
    }

}
